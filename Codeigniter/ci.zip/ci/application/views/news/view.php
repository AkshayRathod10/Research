<?php

echo $news_item['text'];