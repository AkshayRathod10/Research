<?php echo validation_errors(); ?>

<?php echo form_open('news/create'); ?>

<div class="form-group">
    <label for="title">Title</label>
    <input type="input" name="title" class="form-control" /><br />
</div>
<div class="form-group">
    <label for="text">Text</label>
    <textarea name="text" class="form-control"></textarea><br />
</div>

<input type="submit" name="submit" value="Create news item" class="btn btn-primary"/>

</form>